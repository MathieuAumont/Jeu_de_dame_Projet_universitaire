from Partie2.interface_dames import FenetrePartie

if __name__ == '__main__':
    # Point d'entrée principal
    fenetre = FenetrePartie()
    fenetre.mainloop()